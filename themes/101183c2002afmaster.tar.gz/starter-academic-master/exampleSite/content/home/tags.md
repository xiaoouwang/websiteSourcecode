---
# An instance of the Tag Cloud widget.
# Documentation: https://sourcethemes.com/academic/docs/page-builder/
widget: tag_cloud

# Activate this widget? true/false
active: true

# This file represents a page section.
headless: true

# Order that this section appears on the page.
weight: 120

title: Popular Topics
subtitle:

content:
  # Choose how many tags you would like to display (0 = all tags)
  count: 20
  
  # Choose the taxonomy from `config.toml` to display (e.g. tags, categories)
  taxonomy: tags

design:
  font_size_min: 0.7
  font_size_max: 2
---
